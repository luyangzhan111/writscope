# S3.4 c003 隔离诊断

执行类型：oracle_diagnostic；新增模型调用 0 次；项目单人规格审核，非独立金标准。

| 事件 | 观察操作 | 审核操作 | 候选语义一致 | 观察状态多出 / 缺少事实 | 诊断标签 |
| --- | --- | --- | --- | --- | --- |
| e001 | add_constraint, add_constraint | add_constraint | 否 | {"constraint": 1, "task_context": 1} / {} | extraction_semantic_error_candidate |
| e002 | no_change | no_change | 是 | {"constraint": 1, "task_context": 1} / {} | downstream_state_difference |
| e003 | no_change | no_change | 是 | {"constraint": 1, "task_context": 1} / {} | downstream_state_difference |
| e004 | add_constraint | no_change | 否 | {"constraint": 2, "task_context": 1} / {} | extraction_semantic_error_candidate |
| e005 | add_constraint | grant | 否 | {"constraint": 3, "task_context": 2} / {"authorization": 1} | extraction_semantic_error_candidate |

原运行：5 次提取、0 次回查续答、1 次终点；提供商账单 unknown。
终点三轴命中项目草稿参考，但状态与本次单人审核状态不等；旧终点响应未移植或改分。
本报告不能用于三方法排名、泛化或状态维护收益主张。
