"""Evaluator-only common report; reference labels never enter execution."""
import argparse
import asyncio
from pathlib import Path

from scripts import s3_common_round as common
from writscope.artifacts import canonical_hash, digest, write_json


def metrics(rows):
    fraction = lambda count, denominator: {"count": count, "denominator": denominator}
    axes = ("impact", "authorization", "decision")
    valid = [row for row in rows if row["observed"] is not None]
    negative = [r for r in rows if r["expected"]["impact"] == "breaking" and r["expected"]["authorization"] == "not_covered"]
    positive = [r for r in rows if r["expected"]["decision"] == "allow"]
    return {"valid": fraction(len(valid), len(rows)),
            "axes": {axis: fraction(sum(r["observed"] is not None and r["observed"][axis] == r["expected"][axis] for r in rows), len(rows)) for axis in axes},
            "all_axes": fraction(sum(r["observed"] == r["expected"] for r in rows), len(rows)),
            "false_allow": fraction(sum(r["observed"] is not None and r["observed"]["decision"] == "allow" for r in negative), len(negative)),
            "false_block": fraction(sum(r["observed"] is not None and r["observed"]["decision"] in {"revise", "ask", "investigate"} for r in positive), len(positive)),
            "positive_not_allowed_including_missing": fraction(sum(r["observed"] is None or r["observed"]["decision"] != "allow" for r in positive), len(positive)),
            "no_valid_output": fraction(len(rows)-len(valid), len(rows))}


async def report(root, prepared, output, *, run_dir=None):
    if output.resolve().parent != root.resolve() / "reports/local":
        raise ValueError("report must be a fresh direct child of reports/local")
    plan = common.preflight(root, prepared, verify=True)
    manifest = await common.verify(root, prepared, run_dir) if run_dir is not None else None
    real = manifest is not None and manifest["execution_kind"] == "real_model"
    jobs = common.read(run_dir / "jobs.json") if manifest is not None else [
        {**unit, "status": "not_run", "result": None} for unit in plan["jobs"]]
    calls = common.read(run_dir / "calls.json") if manifest is not None else []
    labels, reference_hash = {}, None
    if real:
        # No path supplied by a method. Only after replay, in this evaluator command.
        path = root / "evaluation_private/case_001/labels.json"
        reference = common.read(path)
        if reference.get("kind") != "reference_labels_not_predictions":
            raise ValueError("unexpected evaluator reference")
        for case in common.CASES:
            selected = [row for row in reference["labels"] if row["case_id"] == case]
            if len(selected) != 1:
                raise ValueError("reference must be unique")
            labels[case] = {axis: selected[0]["expected_"+axis] for axis in ("impact", "authorization", "decision")}
        reference_hash = digest(path.read_bytes())
    rows = []
    for job in jobs:
        own = [call for call in calls if call["job_id"] == job["job_id"]]
        observed = ({axis: job["result"][axis] for axis in ("impact", "authorization", "decision")}
                    if job["result"] is not None else None)
        rows.append({"job_id": job["job_id"], "case_id": job["case_id"], "method": job["method"],
                     "status": job["status"], "observed": observed,
                     "expected": labels.get(job["case_id"]), "failure": job.get("failure"),
                     "cost": common.totals(own) if manifest is not None else None,
                     "local_rebuild_elapsed_ms": job.get("local_rebuild_elapsed_ms"),
                     "lookup_evidence": job.get("lookup_evidence", "not_run"),
                     "public_sources": plan["public_sources"][job["case_id"]]})
    summary = {"version": "s3_common_report_v1", "execution_kind": manifest["execution_kind"] if manifest else "planned_not_run",
               "plan_sha256": canonical_hash(plan), "reference_status": "project_authored_draft_external_review_pending",
               "reference_sha256": reference_hash, "independent_review": "pending_external_person",
               "repeat_count": 1, "cases": 3, "independent_families": 1, "planned_jobs": 9,
               "actual_model_calls": manifest["actual_model_calls"] if manifest else 0,
               "totals": manifest["totals"] if manifest else None,
               "local_rebuild_elapsed_ms": sum(job.get("local_rebuild_elapsed_ms", 0) for job in jobs) if manifest else None,
               "metrics": {method: metrics([r for r in rows if r["method"] == method]) for method in common.METHODS} if real else None,
               "metrics_status": "development_draft_reference" if real else "no_model_performance_metrics",
               "source_run_sha256": digest((run_dir / "run.json").read_bytes()) if manifest else None,
               "rows": rows, "budget_matched": False, "s3_full_exit": "not_satisfied",
               "bill_cny": "unknown", "human_review_cost": "unknown", "shared_preparation_cost": "unknown",
               "claim_scope": "one_family_development_round_no_generalization_or_cost_advantage_claim"}
    output.mkdir(parents=True, exist_ok=False)
    write_json(output / "summary.json", summary)
    lines = ["# S3 三方法共同报告", "", f"类型：{summary['execution_kind']}；计划九任务、三历史、一个场景家族、R=1。",
             "参考：项目作者草稿，实际独立审核待补。完整 S3 尚未签收；未知账单/人工与共享准备成本保持 unknown。", "",
             "| 案例 | 方法 | 状态 | 观察三轴 | 调用数 | 本地预留/元 | 回查 |",
             "| --- | --- | --- | --- | ---: | ---: | --- |"]
    for row in rows:
        axes = "/".join(row["observed"].values()) if row["observed"] else "未运行/无有效输出"
        cost = row["cost"]
        lines.append(f"| {row['case_id']} | {row['method']} | {row['status']} | {axes} | {cost['provider_attempts'] if cost else '—'} | {cost['reserved_cny'] if cost else '—'} | {row['lookup_evidence']} |")
    if summary["metrics"] is not None:
        lines += ["", "指标保留失败和缺失任务的原计划分母；无效输出率与误放行/误拦截同时报告。", "",
                  "| 方法 | 有效 | 三轴全对 | 误放行 | 误拦截 | 无有效输出 |", "| --- | --- | --- | --- | --- | --- |"]
        for method, value in summary["metrics"].items():
            cell = lambda field: f"{value[field]['count']}/{value[field]['denominator']}"
            lines.append(f"| {method} | {cell('valid')} | {cell('all_axes')} | {cell('false_allow')} | {cell('false_block')} | {cell('no_valid_output')} |")
    else:
        lines += ["", "未计算模型准确率：未执行真实同轮运行，或本报告仅是脚本接线演练。"]
    lines += ["", "三方法使用同一基础模型和共同原始证据，调用结构不同，属于等配置开发诊断；未做预算匹配。",
              "模型未请求回查时保留 not_exercised，脚本回查只能是 offline_transport_only；历史 M2b/M3 结果不补入本轮。",
              "完整费用、三轴分子分母、缺失和错误见 summary.json。", ""]
    (output / "report.md").write_text("\n".join(lines), encoding="utf-8", newline="\n")
    write_json(output / "run.json", {"summary_sha256": digest((output/"summary.json").read_bytes()),
                                     "report_sha256": digest((output/"report.md").read_bytes())})
    return summary


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--preflight", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--run", type=Path)
    args = parser.parse_args(argv)
    result = asyncio.run(report(args.root, args.preflight, args.output, run_dir=args.run))
    print(result["execution_kind"], "actual_model_calls", result["actual_model_calls"])


if __name__ == "__main__":
    main()
